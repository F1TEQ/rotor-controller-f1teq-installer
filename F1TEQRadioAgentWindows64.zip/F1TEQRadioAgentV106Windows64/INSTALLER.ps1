﻿#requires -version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = Join-Path $env:LOCALAPPDATA 'F1TEQ\RadioAgentApp'
$DataRoot = Join-Path $env:APPDATA 'F1TEQ\RadioAgent'
$HamlibRoot = Join-Path $AppRoot 'Hamlib'
$LogFile = Join-Path $DataRoot 'installation.log'
$ArchiveLocal = Join-Path $Root 'Hamlib472.zip'
$ArchiveCache = Join-Path $DataRoot 'Hamlib472.zip'
$ExpectedHash = '8553bc6c5c6032e8debf99c017e98f58fed7e07e7c25d04815dc3e8bbe3304c7'
$AgentScript = Join-Path $Root 'F1TEQRadioAgent.ps1'
$WorkerScript = Join-Path $Root 'F1TEQRadioAgentWorker.ps1'

$Urls = @(
    'https://github.com/Hamlib/Hamlib/releases/download/4.7.2/hamlib-w64-4.7.2.zip',
    'https://downloads.sourceforge.net/project/hamlib/hamlib/4.7.2/hamlib-w64-4.7.2.zip',
    'https://sourceforge.net/projects/hamlib/files/hamlib/4.7.2/hamlib-w64-4.7.2.zip/download'
)

function WriteStep {
    param([string]$Text)
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$stamp] $Text"
    Write-Host $line
    try { Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 } catch {}
}

function AssertFile {
    param([string]$Path, [string]$Description)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "$Description est absent : $Path"
    }
}

function TestZipSignature {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $item = Get-Item -LiteralPath $Path
    if ($item.Length -lt 2000000) { return $false }
    $stream = [IO.File]::OpenRead($Path)
    try {
        $a = $stream.ReadByte()
        $b = $stream.ReadByte()
        return ($a -eq 0x50 -and $b -eq 0x4B)
    } finally {
        $stream.Dispose()
    }
}

function TestArchiveHash {
    param([string]$Path)
    if (-not (TestZipSignature $Path)) { return $false }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    WriteStep "Empreinte SHA256 recue : $actual"
    return ($actual -eq $ExpectedHash)
}

function RemoveQuietly {
    param([string]$Path)
    Remove-Item -LiteralPath $Path -Force -Recurse -ErrorAction SilentlyContinue
}

function DownloadWithBits {
    param([string]$Url, [string]$Destination)
    $bits = Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue
    if (-not $bits) { throw 'BITS indisponible' }
    WriteStep "Essai BITS : $Url"
    Start-BitsTransfer -Source $Url -Destination $Destination -DisplayName 'F1TEQ Hamlib 4.7.2' -Description 'Telechargement Hamlib pour F1TEQ Radio Agent' -ErrorAction Stop
}

function DownloadWithCurl {
    param([string]$Url, [string]$Destination)
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if (-not $curl) { throw 'curl.exe indisponible' }
    WriteStep "Essai curl : $Url"
    & $curl.Source -L --fail --retry 3 --retry-delay 2 --connect-timeout 20 --max-time 600 --output $Destination $Url
    if ($LASTEXITCODE -ne 0) { throw "curl a retourne le code $LASTEXITCODE" }
}

function DownloadWithWebRequest {
    param([string]$Url, [string]$Destination)
    WriteStep "Essai PowerShell : $Url"
    $oldProgress = $ProgressPreference
    $ProgressPreference = 'Continue'
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination -TimeoutSec 600 -Headers @{ 'User-Agent' = 'F1TEQRadioAgentInstaller/1.0.6' }
    } finally {
        $ProgressPreference = $oldProgress
    }
}

function GetHamlibArchive {
    if (Test-Path -LiteralPath $ArchiveLocal -PathType Leaf) {
        WriteStep 'Archive Hamlib472.zip trouvee a cote de l installateur.'
        if (TestArchiveHash $ArchiveLocal) { return $ArchiveLocal }
        throw 'Le fichier Hamlib472.zip present dans le pack est incomplet ou son empreinte est incorrecte.'
    }

    if (Test-Path -LiteralPath $ArchiveCache -PathType Leaf) {
        WriteStep 'Verification de l archive Hamlib deja presente dans le cache.'
        if (TestArchiveHash $ArchiveCache) { return $ArchiveCache }
        WriteStep 'Archive en cache invalide. Elle sera remplacee.'
        RemoveQuietly $ArchiveCache
    }

    $methods = @('BITS','CURL','WEB')
    foreach ($url in $Urls) {
        foreach ($method in $methods) {
            RemoveQuietly $ArchiveCache
            try {
                switch ($method) {
                    'BITS' { DownloadWithBits $url $ArchiveCache }
                    'CURL' { DownloadWithCurl $url $ArchiveCache }
                    'WEB'  { DownloadWithWebRequest $url $ArchiveCache }
                }
                if (-not (TestZipSignature $ArchiveCache)) {
                    throw 'Le serveur a renvoye un fichier trop petit ou une page HTML.'
                }
                if (-not (TestArchiveHash $ArchiveCache)) {
                    throw 'Empreinte SHA256 incorrecte.'
                }
                WriteStep 'Telechargement de Hamlib valide.'
                return $ArchiveCache
            } catch {
                WriteStep "Echec $method : $($_.Exception.Message)"
            }
        }
    }

    throw "Aucune methode de telechargement n a fonctionne. Vous pouvez telecharger manuellement hamlib w64 4.7.2 zip depuis la publication officielle, le renommer Hamlib472.zip, le placer a cote de INSTALLER.cmd, puis relancer l installation."
}

function FindRigctl {
    param([string]$Base)
    $file = Get-ChildItem -LiteralPath $Base -Filter 'rigctl.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($file) { return $file.FullName }
    return $null
}

function InstallHamlib {
    $existing = FindRigctl $HamlibRoot
    if ($existing) {
        try {
            $versionText = (& $existing --version 2>&1 | Out-String).Trim()
            WriteStep "Hamlib deja installe : $versionText"
            if ($versionText -match '4\.7\.2') { return $existing }
        } catch {
            WriteStep "Hamlib existant inutilisable : $($_.Exception.Message)"
        }
    }

    $archive = GetHamlibArchive
    $temp = Join-Path $DataRoot ('HamlibTemp' + [Guid]::NewGuid().ToString('N'))
    RemoveQuietly $temp
    New-Item -ItemType Directory -Force -Path $temp | Out-Null

    WriteStep 'Decompression de Hamlib 4.7.2.'
    Expand-Archive -LiteralPath $archive -DestinationPath $temp -Force
    $rig = FindRigctl $temp
    if (-not $rig) { throw 'rigctl.exe est absent apres la decompression.' }

    RemoveQuietly $HamlibRoot
    Move-Item -LiteralPath $temp -Destination $HamlibRoot
    $rig = FindRigctl $HamlibRoot
    if (-not $rig) { throw 'rigctl.exe est introuvable dans le dossier Hamlib installe.' }

    $versionText = (& $rig --version 2>&1 | Out-String).Trim()
    WriteStep "Hamlib installe : $versionText"
    return $rig
}

function CreateShortcut {
    param([string]$ShortcutPath, [string]$TargetPath, [string]$Arguments, [string]$WorkingDirectory)
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = $TargetPath
    $shortcut.Arguments = $Arguments
    $shortcut.WorkingDirectory = $WorkingDirectory
    $shortcut.Description = 'F1TEQ Radio Agent universel Hamlib'
    $shortcut.Save()
}

try {
    New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
    WriteStep 'Debut de l installation F1TEQ Radio Agent 1.0.6.'

    if (-not [Environment]::Is64BitOperatingSystem) {
        throw 'Ce pack est reserve a Windows 64 bits.'
    }
    AssertFile $AgentScript 'F1TEQRadioAgent.ps1'
    AssertFile $WorkerScript 'F1TEQRadioAgentWorker.ps1'

    WriteStep 'Arret de l ancienne version si elle est ouverte.'
    Get-Process -Name 'F1TEQRadioAgent' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    try {
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -match '(?i)(F1TEQRadioAgent|F1TEQRadioAgentWorker|F1TEQ_Radio_Agent)\.ps1' } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch {
        WriteStep "Arret de l ancienne instance non confirme : $($_.Exception.Message)"
    }
    Start-Sleep -Milliseconds 800

    New-Item -ItemType Directory -Force -Path $AppRoot | Out-Null
    foreach ($name in @('F1TEQRadioAgent.ps1','F1TEQRadioAgentWorker.ps1','LISEZMOI.txt','NOTICEHAMLIB.txt','VERSION.txt','CORRECTIONINTERFACE.txt')) {
        $src = Join-Path $Root $name
        if (Test-Path -LiteralPath $src -PathType Leaf) {
            Copy-Item -LiteralPath $src -Destination (Join-Path $AppRoot $name) -Force
            WriteStep "Copie de $name."
        }
    }

    $rigctl = InstallHamlib

    WriteStep 'Verification de la liste des modeles Hamlib.'
    $modelLines = & $rigctl -l 2>&1
    $modelExitCode = $LASTEXITCODE
    $modelCount = @($modelLines | Where-Object { [string]$_ -match '^\s*\d+\s+' }).Count
    if ($modelCount -lt 50) { throw "La liste Hamlib semble incomplete : $modelCount modeles, code $modelExitCode." }
    if ($modelExitCode -ne 0) { WriteStep "Avertissement : rigctl -l a retourne le code $modelExitCode, mais $modelCount lignes valides ont ete detectees." }
    WriteStep "$modelCount lignes de modeles Hamlib detectees."

    $oldExe = Join-Path $AppRoot 'F1TEQRadioAgent.exe'
    if (Test-Path -LiteralPath $oldExe) {
        Remove-Item -LiteralPath $oldExe -Force -ErrorAction SilentlyContinue
        WriteStep 'Ancien lanceur executable non signe supprime.'
    }

    Remove-Item -LiteralPath (Join-Path $DataRoot 'worker.pid') -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $DataRoot 'arretdemande.txt') -Force -ErrorAction SilentlyContinue

    $installedScript = Join-Path $AppRoot 'F1TEQRadioAgent.ps1'
    Unblock-File -LiteralPath $installedScript -ErrorAction SilentlyContinue
    Unblock-File -LiteralPath (Join-Path $AppRoot 'F1TEQRadioAgentWorker.ps1') -ErrorAction SilentlyContinue
    $powerShellExe = Join-Path $PSHOME 'powershell.exe'
    $quotedScript = '"' + $installedScript + '"'
    $desktopArguments = '-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File ' + $quotedScript
    $desktop = [Environment]::GetFolderPath('Desktop')
    CreateShortcut (Join-Path $desktop 'F1TEQ Radio Agent.lnk') $powerShellExe $desktopArguments $AppRoot
    WriteStep 'Raccourci PowerShell cree sur le Bureau.'

    WriteStep 'Lancement de F1TEQ Radio Agent via le PowerShell signe de Windows.'
    $launchArguments = '-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $installedScript + '"'
    Start-Process -FilePath $powerShellExe -ArgumentList $launchArguments -WorkingDirectory $AppRoot
    Start-Sleep -Seconds 2
    $agentRunning = Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -and $_.CommandLine.Contains($installedScript) } |
        Select-Object -First 1
    if (-not $agentRunning) {
        $agentLog = Join-Path $DataRoot 'agent.log'
        $details = if (Test-Path -LiteralPath $agentLog) { (Get-Content -LiteralPath $agentLog -Tail 8 | Out-String).Trim() } else { 'Aucun journal agent.' }
        throw "L agent ne reste pas ouvert apres son lancement. Dernieres informations : $details"
    }
    WriteStep 'Agent demarre et processus confirme.'
    WriteStep 'Installation terminee avec succes.'
    exit 0
} catch {
    WriteStep "ERREUR : $($_.Exception.Message)"
    Write-Host ''
    Write-Host 'DETAIL COMPLET :' -ForegroundColor Red
    Write-Host ($_ | Out-String) -ForegroundColor Red
    Write-Host ''
    Write-Host "Journal : $LogFile"
    exit 1
}
