﻿#requires -version 5.1
<#
F1TEQ Radio Agent 1.0.6 - interface graphique
Toutes les operations lentes sont executees par F1TEQRadioAgentWorker.ps1.
L interface ne fait ni requete reseau, ni appel Hamlib.
#>

param([switch]$StartMinimized)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:AgentVersion = '1.0.6'
$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:WorkerScript = Join-Path $script:Root 'F1TEQRadioAgentWorker.ps1'
$script:DataRoot = Join-Path $env:APPDATA 'F1TEQ\RadioAgent'
$script:ConfigFile = Join-Path $script:DataRoot 'config.json'
$script:StatusFile = Join-Path $script:DataRoot 'workerstatus.json'
$script:PidFile = Join-Path $script:DataRoot 'worker.pid'
$script:StopFile = Join-Path $script:DataRoot 'arretdemande.txt'
$script:ShowRequestFile = Join-Path $script:DataRoot 'afficherfenetre.demande'
$script:LogFile = Join-Path $script:DataRoot 'agent.log'
$script:PowerShellExe = Join-Path $PSHOME 'powershell.exe'
$script:StartupShortcut = Join-Path ([Environment]::GetFolderPath('Startup')) 'F1TEQ Radio Agent.lnk'
$script:Exiting = $false
$script:LastLogWriteUtc = [DateTime]::MinValue
$script:LastStatusText = ''
$script:WorkerStopRequestedAt = $null

New-Item -ItemType Directory -Force -Path $script:DataRoot | Out-Null

$createdNew = $false
$script:SingleInstanceMutex = [System.Threading.Mutex]::new($true, 'Local\F1TEQRadioAgentUI', [ref]$createdNew)
if (-not $createdNew) {
    try { Set-Content -LiteralPath $script:ShowRequestFile -Value (Get-Date).ToString('o') -Encoding ASCII -Force } catch {}
    [System.Windows.Forms.MessageBox]::Show(
        'F1TEQ Radio Agent est deja ouvert. Sa fenetre va etre reaffichee.',
        'F1TEQ Radio Agent',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    exit
}

function Write-UiLog {
    param([string]$Message)
    $line = '[{0}] INTERFACE : {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    try { Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8 } catch {}
}

function Normalize-ControllerUrl {
    param([string]$Value)
    $value = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) { return $null }
    if ($value -notmatch '^https?://') { $value = 'http://' + $value }
    return $value.TrimEnd('/')
}

function Get-ControllerUrls {
    $items = New-Object System.Collections.Generic.List[string]
    foreach ($line in ($script:ControllersBox.Text -split '[,;\r\n]+')) {
        $url = Normalize-ControllerUrl $line
        if ($url -and -not $items.Contains($url)) { $items.Add($url) }
    }
    return @($items)
}

function Write-JsonAtomic {
    param([string]$Path, $Value)
    $tmp = $Path + '.tmp.' + [Guid]::NewGuid().ToString('N')
    try {
        $Value | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $tmp -Encoding UTF8
        Move-Item -LiteralPath $tmp -Destination $Path -Force
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Load-Config {
    $default = [pscustomobject]@{
        controllers = @('http://rotor.local')
        start_with_windows = $false
        start_minimized = $false
    }
    if (-not (Test-Path -LiteralPath $script:ConfigFile)) { return $default }
    try {
        $data = Get-Content -LiteralPath $script:ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $data.controllers) { $data | Add-Member -NotePropertyName controllers -NotePropertyValue @('http://rotor.local') -Force }
        if (-not $data.PSObject.Properties['start_with_windows']) { $data | Add-Member -NotePropertyName start_with_windows -NotePropertyValue $false -Force }
        if (-not $data.PSObject.Properties['start_minimized']) { $data | Add-Member -NotePropertyName start_minimized -NotePropertyValue $false -Force }
        return $data
    } catch {
        Write-UiLog "Configuration illisible : $($_.Exception.Message)"
        return $default
    }
}

function Set-StartupShortcut {
    param([bool]$Enable)
    try {
        if ($Enable) {
            $shell = New-Object -ComObject WScript.Shell
            $shortcut = $shell.CreateShortcut($script:StartupShortcut)
            $shortcut.TargetPath = $script:PowerShellExe
            $quotedScript = '"' + (Join-Path $script:Root 'F1TEQRadioAgent.ps1') + '"'
            $shortcut.Arguments = '-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File ' + $quotedScript + ' -StartMinimized'
            $shortcut.WorkingDirectory = $script:Root
            $shortcut.Description = 'F1TEQ Radio Agent universel'
            $shortcut.Save()
        } elseif (Test-Path -LiteralPath $script:StartupShortcut) {
            Remove-Item -LiteralPath $script:StartupShortcut -Force
        }
    } catch {
        Write-UiLog "Raccourci de demarrage Windows : $($_.Exception.Message)"
    }
}

function Save-Config {
    try {
        $config = [ordered]@{
            controllers = @(Get-ControllerUrls)
            start_with_windows = [bool]$script:StartupCheck.Checked
            start_minimized = [bool]$script:MinimizedCheck.Checked
        }
        Write-JsonAtomic -Path $script:ConfigFile -Value $config
        Set-StartupShortcut -Enable:$script:StartupCheck.Checked
        return $true
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Impossible d enregistrer les parametres : $($_.Exception.Message)",
            'F1TEQ Radio Agent',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        return $false
    }
}

function Get-WorkerPid {
    try {
        if (-not (Test-Path -LiteralPath $script:PidFile)) { return 0 }
        $value = (Get-Content -LiteralPath $script:PidFile -Raw -ErrorAction Stop).Trim()
        $pidValue = 0
        if ([int]::TryParse($value, [ref]$pidValue)) { return $pidValue }
    } catch {}
    return 0
}

function Test-WorkerRunning {
    $pidValue = Get-WorkerPid
    if ($pidValue -le 0) { return $false }
    return $null -ne (Get-Process -Id $pidValue -ErrorAction SilentlyContinue)
}

function Set-UiStatus {
    param([string]$Text, [System.Drawing.Color]$Color = [System.Drawing.Color]::DarkSlateGray)
    if ($script:StatusLabel.Text -ne $Text) { $script:StatusLabel.Text = $Text }
    $script:StatusLabel.ForeColor = $Color
}

function Start-Worker {
    if (-not (Save-Config)) { return }
    if (-not (Test-Path -LiteralPath $script:WorkerScript -PathType Leaf)) {
        Set-UiStatus 'Moteur de l agent absent. Relancez INSTALLER.cmd.' ([System.Drawing.Color]::DarkRed)
        return
    }
    if (Test-WorkerRunning) {
        Set-UiStatus 'Agent deja actif en arriere-plan.' ([System.Drawing.Color]::DarkGreen)
        return
    }
    Remove-Item -LiteralPath $script:StopFile -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $script:PidFile -Force -ErrorAction SilentlyContinue
    $quotedWorker = '"' + $script:WorkerScript + '"'
    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ' + $quotedWorker
    try {
        Start-Process -FilePath $script:PowerShellExe -ArgumentList $arguments -WorkingDirectory $script:Root -WindowStyle Hidden
        $script:WorkerStopRequestedAt = $null
        Set-UiStatus 'Demarrage du moteur Hamlib...' ([System.Drawing.Color]::DarkOrange)
        $script:StartButton.Enabled = $false
        $script:StopButton.Enabled = $true
        Write-UiLog 'Demarrage du moteur demande.'
    } catch {
        Set-UiStatus "Demarrage impossible : $($_.Exception.Message)" ([System.Drawing.Color]::DarkRed)
        Write-UiLog "Demarrage impossible : $($_.Exception.Message)"
    }
}

function Stop-Worker {
    param([switch]$Force)
    try { Set-Content -LiteralPath $script:StopFile -Value (Get-Date).ToString('o') -Encoding ASCII -Force } catch {}
    $pidValue = Get-WorkerPid
    if ($Force -and $pidValue -gt 0) {
        Stop-Process -Id $pidValue -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $script:PidFile -Force -ErrorAction SilentlyContinue
    }
    $script:WorkerStopRequestedAt = Get-Date
    Set-UiStatus 'Arret du moteur demande...' ([System.Drawing.Color]::DarkOrange)
    Write-UiLog 'Arret du moteur demande.'
}

function Refresh-LogBox {
    try {
        if (-not (Test-Path -LiteralPath $script:LogFile)) { return }
        $item = Get-Item -LiteralPath $script:LogFile
        if ($item.LastWriteTimeUtc -le $script:LastLogWriteUtc) { return }
        $script:LastLogWriteUtc = $item.LastWriteTimeUtc
        $text = (Get-Content -LiteralPath $script:LogFile -Tail 220 -ErrorAction Stop) -join [Environment]::NewLine
        $script:LogBox.Text = $text
        $script:LogBox.SelectionStart = $script:LogBox.TextLength
        $script:LogBox.ScrollToCaret()
    } catch {}
}

function Refresh-WorkerStatus {
    $running = Test-WorkerRunning
    $status = $null
    if (Test-Path -LiteralPath $script:StatusFile) {
        try { $status = Get-Content -LiteralPath $script:StatusFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
    }

    if ($running) {
        $script:StartButton.Enabled = $false
        $script:StopButton.Enabled = $true
        if ($status -and $status.message) {
            $text = [string]$status.message
            switch ([string]$status.state) {
                'running' { Set-UiStatus $text ([System.Drawing.Color]::DarkGreen) }
                'error' { Set-UiStatus $text ([System.Drawing.Color]::DarkRed) }
                default { Set-UiStatus $text ([System.Drawing.Color]::DarkOrange) }
            }
            if ($script:NotifyIcon) {
                $short = if ($text.Length -gt 38) { $text.Substring(0,38) } else { $text }
                $script:NotifyIcon.Text = 'F1TEQ Radio Agent - ' + $short
            }
        } else {
            Set-UiStatus 'Moteur en cours de demarrage...' ([System.Drawing.Color]::DarkOrange)
        }
    } else {
        $script:StartButton.Enabled = $true
        $script:StopButton.Enabled = $false
        if ($status -and [string]$status.state -eq 'error') {
            Set-UiStatus ([string]$status.message) ([System.Drawing.Color]::DarkRed)
        } elseif ($script:WorkerStopRequestedAt) {
            Set-UiStatus 'Agent arrete.' ([System.Drawing.Color]::DarkSlateGray)
            $script:WorkerStopRequestedAt = $null
        } else {
            Set-UiStatus 'Agent arrete.' ([System.Drawing.Color]::DarkSlateGray)
        }
        if ($script:NotifyIcon) { $script:NotifyIcon.Text = 'F1TEQ Radio Agent - arrete' }
    }
    Refresh-LogBox
}

function Show-AgentWindow {
    if ($script:Form -and -not $script:Form.IsDisposed) {
        $script:Form.Show()
        $script:Form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $script:Form.ShowInTaskbar = $true
        $script:Form.Activate()
        $script:Form.BringToFront()
    }
}

function Check-ShowRequest {
    if (Test-Path -LiteralPath $script:ShowRequestFile) {
        Remove-Item -LiteralPath $script:ShowRequestFile -Force -ErrorAction SilentlyContinue
        Show-AgentWindow
    }
}

function Open-Controller {
    $urls = @(Get-ControllerUrls)
    if ($urls.Count -gt 0) { Start-Process $urls[0] }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'F1TEQ Radio Agent universel'
$form.Size = New-Object System.Drawing.Size(790,610)
$form.MinimumSize = New-Object System.Drawing.Size(790,610)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI',9)
$form.BackColor = [System.Drawing.Color]::FromArgb(242,247,251)
$script:Form = $form

$title = New-Object System.Windows.Forms.Label
$title.Text = 'F1TEQ Radio Agent universel'
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold',18)
$title.ForeColor = [System.Drawing.Color]::FromArgb(8,54,86)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20,16)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = 'Interface 1.0.6 non bloquante — moteur Hamlib execute en arriere-plan'
$subtitle.AutoSize = $true
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(55,91,117)
$subtitle.Location = New-Object System.Drawing.Point(23,54)
$form.Controls.Add($subtitle)

$controllersLabel = New-Object System.Windows.Forms.Label
$controllersLabel.Text = 'Adresses des controleurs (une par ligne)'
$controllersLabel.AutoSize = $true
$controllersLabel.Location = New-Object System.Drawing.Point(22,88)
$form.Controls.Add($controllersLabel)

$controllers = New-Object System.Windows.Forms.TextBox
$controllers.Multiline = $true
$controllers.ScrollBars = 'Vertical'
$controllers.Location = New-Object System.Drawing.Point(24,110)
$controllers.Size = New-Object System.Drawing.Size(480,78)
$controllers.Anchor = 'Top,Left,Right'
$script:ControllersBox = $controllers
$form.Controls.Add($controllers)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = 'DEMARRER'
$startButton.Location = New-Object System.Drawing.Point(525,110)
$startButton.Size = New-Object System.Drawing.Size(112,34)
$startButton.BackColor = [System.Drawing.Color]::FromArgb(30,145,214)
$startButton.ForeColor = [System.Drawing.Color]::White
$startButton.FlatStyle = 'Flat'
$script:StartButton = $startButton
$form.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = 'ARRETER'
$stopButton.Location = New-Object System.Drawing.Point(645,110)
$stopButton.Size = New-Object System.Drawing.Size(112,34)
$stopButton.Enabled = $false
$script:StopButton = $stopButton
$form.Controls.Add($stopButton)

$applyButton = New-Object System.Windows.Forms.Button
$applyButton.Text = 'APPLIQUER LES ADRESSES'
$applyButton.Location = New-Object System.Drawing.Point(525,153)
$applyButton.Size = New-Object System.Drawing.Size(232,35)
$form.Controls.Add($applyButton)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = 'OUVRIR LE CONTROLEUR'
$openButton.Location = New-Object System.Drawing.Point(525,196)
$openButton.Size = New-Object System.Drawing.Size(232,35)
$form.Controls.Add($openButton)

$startupCheck = New-Object System.Windows.Forms.CheckBox
$startupCheck.Text = 'Demarrer automatiquement avec Windows'
$startupCheck.AutoSize = $true
$startupCheck.Location = New-Object System.Drawing.Point(24,202)
$script:StartupCheck = $startupCheck
$form.Controls.Add($startupCheck)

$minimizedCheck = New-Object System.Windows.Forms.CheckBox
$minimizedCheck.Text = 'Demarrer reduit dans la zone de notification'
$minimizedCheck.AutoSize = $true
$minimizedCheck.Location = New-Object System.Drawing.Point(24,228)
$script:MinimizedCheck = $minimizedCheck
$form.Controls.Add($minimizedCheck)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object System.Drawing.Point(24,260)
$statusPanel.Size = New-Object System.Drawing.Size(733,48)
$statusPanel.Anchor = 'Top,Left,Right'
$statusPanel.BackColor = [System.Drawing.Color]::White
$statusPanel.BorderStyle = 'FixedSingle'
$form.Controls.Add($statusPanel)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = 'Agent arrete.'
$statusLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$statusLabel.AutoSize = $true
$statusLabel.Location = New-Object System.Drawing.Point(12,13)
$script:StatusLabel = $statusLabel
$statusPanel.Controls.Add($statusLabel)

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = 'Journal'
$logLabel.AutoSize = $true
$logLabel.Location = New-Object System.Drawing.Point(22,324)
$form.Controls.Add($logLabel)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = 'Vertical'
$logBox.Font = New-Object System.Drawing.Font('Consolas',8.5)
$logBox.Location = New-Object System.Drawing.Point(24,346)
$logBox.Size = New-Object System.Drawing.Size(733,185)
$logBox.Anchor = 'Top,Bottom,Left,Right'
$script:LogBox = $logBox
$form.Controls.Add($logBox)

$note = New-Object System.Windows.Forms.Label
$note.Text = 'Le modele, le port COM et le debit exact du poste se choisissent dans Ma station sur le Rotor Controller.'
$note.AutoSize = $true
$note.ForeColor = [System.Drawing.Color]::FromArgb(55,91,117)
$note.Location = New-Object System.Drawing.Point(24,547)
$note.Anchor = 'Bottom,Left'
$form.Controls.Add($note)

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.SystemIcons]::Application
$notify.Text = 'F1TEQ Radio Agent'
$notify.Visible = $true
$script:NotifyIcon = $notify
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$showItem = $menu.Items.Add('Afficher')
$openItem = $menu.Items.Add('Ouvrir le controleur')
$quitItem = $menu.Items.Add('Quitter')
$notify.ContextMenuStrip = $menu

$uiTimer = New-Object System.Windows.Forms.Timer
$uiTimer.Interval = 700
$uiTimer.Add_Tick({
    Check-ShowRequest
    Refresh-WorkerStatus
})
$uiTimer.Start()
$script:UiTimer = $uiTimer

$startButton.Add_Click({ Start-Worker })
$stopButton.Add_Click({ Stop-Worker })
$applyButton.Add_Click({
    if (Save-Config) {
        Set-UiStatus 'Parametres enregistres. Le moteur les prendra en compte automatiquement.' ([System.Drawing.Color]::DarkGreen)
        Write-UiLog 'Parametres enregistres.'
    }
})
$openButton.Add_Click({ Open-Controller })
$startupCheck.Add_CheckedChanged({ if ($form.Visible) { [void](Save-Config) } })
$minimizedCheck.Add_CheckedChanged({ if ($form.Visible) { [void](Save-Config) } })
$showItem.Add_Click({ Show-AgentWindow })
$openItem.Add_Click({ Open-Controller })
$notify.Add_DoubleClick({ Show-AgentWindow })
$quitItem.Add_Click({
    $script:Exiting = $true
    Stop-Worker -Force
    [void](Save-Config)
    $notify.Visible = $false
    $form.Close()
})
$form.Add_Resize({
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
        $form.Hide()
        $notify.ShowBalloonTip(1500,'F1TEQ Radio Agent','Le moteur continue en arriere-plan. Double-cliquez sur l icone pour reouvrir.',[System.Windows.Forms.ToolTipIcon]::Info)
    }
})
$form.Add_FormClosing({
    if (-not $script:Exiting) {
        $script:Exiting = $true
        try { Stop-Worker -Force } catch {}
        try { [void](Save-Config) } catch {}
        if ($script:NotifyIcon) { $script:NotifyIcon.Visible = $false }
    }
})
$form.Add_Shown({
    if ($StartMinimized -or $script:MinimizedCheck.Checked) {
        $form.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
        $form.Hide()
    }
    Start-Worker
})

$config = Load-Config
$controllers.Text = (@($config.controllers) -join [Environment]::NewLine)
$startupCheck.Checked = [bool]$config.start_with_windows
$minimizedCheck.Checked = [bool]$config.start_minimized
Write-UiLog "F1TEQ Radio Agent $($script:AgentVersion) initialise."
Refresh-LogBox

[System.Windows.Forms.Application]::Run($form)
try { $uiTimer.Stop(); $uiTimer.Dispose() } catch {}
Remove-Item -LiteralPath $script:ShowRequestFile -Force -ErrorAction SilentlyContinue
try { $notify.Dispose() } catch {}
if ($script:SingleInstanceMutex) {
    try { $script:SingleInstanceMutex.ReleaseMutex() } catch {}
    $script:SingleInstanceMutex.Dispose()
}
