﻿#requires -version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Continue'

$AppRoot = Join-Path $env:LOCALAPPDATA 'F1TEQ\RadioAgentApp'
$DataRoot = Join-Path $env:APPDATA 'F1TEQ\RadioAgent'
$Startup = Join-Path ([Environment]::GetFolderPath('Startup')) 'F1TEQ Radio Agent.lnk'
$Desktop = Join-Path ([Environment]::GetFolderPath('Desktop')) 'F1TEQ Radio Agent.lnk'

Write-Host 'Arret de F1TEQ Radio Agent...'
try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -match '(?i)(F1TEQRadioAgent|F1TEQRadioAgentWorker|F1TEQ_Radio_Agent)\.ps1' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}
Start-Sleep -Milliseconds 700

Remove-Item -LiteralPath $Startup -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $Desktop -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $AppRoot -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Programme et raccourcis supprimes.'

$answer = Read-Host 'Supprimer aussi la configuration et les journaux ? Tapez O pour oui'
if ($answer -match '^[oOyY]') {
    Remove-Item -LiteralPath $DataRoot -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host 'Configuration et journaux supprimes.'
} else {
    Write-Host 'Configuration et journaux conserves.'
}
