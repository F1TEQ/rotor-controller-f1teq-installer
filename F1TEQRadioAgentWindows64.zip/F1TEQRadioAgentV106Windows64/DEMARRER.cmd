@echo off
setlocal
chcp 65001 >nul
set "APP=%LOCALAPPDATA%\F1TEQ\RadioAgentApp\F1TEQRadioAgent.ps1"
if not exist "%APP%" (
  echo F1TEQ Radio Agent n est pas encore installe.
  echo Lancez d abord INSTALLER.cmd.
  echo.
  pause
  exit /b 1
)
start "F1TEQ Radio Agent" powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%APP%"
endlocal
