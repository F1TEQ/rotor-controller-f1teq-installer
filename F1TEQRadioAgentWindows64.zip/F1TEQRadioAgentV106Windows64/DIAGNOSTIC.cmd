@echo off
setlocal
chcp 65001 >nul
title Diagnostic F1TEQ Radio Agent
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DIAGNOSTIC.ps1"
echo.
pause
endlocal
