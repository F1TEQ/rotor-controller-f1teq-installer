@echo off
setlocal
cd /d "%~dp0"
title TEST HAMLIB F1TEQ
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0TESTHAMLIB.ps1"
echo.
pause
endlocal
