@echo off
setlocal
chcp 65001 >nul
title Desinstallation F1TEQ Radio Agent
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DESINSTALLER.ps1"
echo.
pause
endlocal
