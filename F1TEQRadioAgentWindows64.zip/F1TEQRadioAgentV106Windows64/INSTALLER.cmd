@echo off
setlocal
chcp 65001 >nul
title Installation F1TEQ Radio Agent
cd /d "%~dp0"

echo ============================================================
echo          INSTALLATION F1TEQ RADIO AGENT 1.0.5
echo ============================================================
echo.
echo Cette fenetre restera ouverte jusqu a la fin.
echo Les erreurs de telechargement de Hamlib seront affichees ici.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLER.ps1"
set "RESULTAT=%ERRORLEVEL%"

echo.
if "%RESULTAT%"=="0" (
  echo INSTALLATION TERMINEE AVEC SUCCES.
) else (
  echo ECHEC DE L INSTALLATION. CODE %RESULTAT%.
  echo Lancez DIAGNOSTIC.cmd pour creer un rapport complet.
)
echo.
pause
exit /b %RESULTAT%
