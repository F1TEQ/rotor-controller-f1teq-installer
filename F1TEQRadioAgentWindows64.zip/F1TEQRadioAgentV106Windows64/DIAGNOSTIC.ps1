﻿#requires -version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Continue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$AppRoot = Join-Path $env:LOCALAPPDATA 'F1TEQ\RadioAgentApp'
$DataRoot = Join-Path $env:APPDATA 'F1TEQ\RadioAgent'
$Desktop = [Environment]::GetFolderPath('Desktop')
$Report = Join-Path $Desktop 'DiagnosticF1TEQ.txt'
$ExpectedHash = '8553bc6c5c6032e8debf99c017e98f58fed7e07e7c25d04815dc3e8bbe3304c7'

$lines = New-Object System.Collections.Generic.List[string]
function AddLine([string]$Text='') { $lines.Add($Text); Write-Host $Text }
function AddCommandResult([string]$Title, [scriptblock]$Command) {
    AddLine ''
    AddLine "===== $Title ====="
    try {
        $out = & $Command 2>&1 | Out-String
        AddLine $out.TrimEnd()
    } catch {
        AddLine "ERREUR : $($_.Exception.Message)"
    }
}

AddLine 'DIAGNOSTIC F1TEQ RADIO AGENT'
AddLine ('Date : ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
AddLine ('Ordinateur : ' + $env:COMPUTERNAME)
AddLine ('Utilisateur : ' + $env:USERNAME)
AddLine ('Windows 64 bits : ' + [Environment]::Is64BitOperatingSystem)
AddLine ('PowerShell : ' + $PSVersionTable.PSVersion.ToString())
AddLine ('Dossier programme : ' + $AppRoot)
AddLine ('Dossier donnees : ' + $DataRoot)

AddCommandResult 'FICHIERS DU PROGRAMME' {
    if (Test-Path -LiteralPath $AppRoot) {
        Get-ChildItem -LiteralPath $AppRoot -Recurse -File | Select-Object FullName,Length,LastWriteTime | Format-Table -AutoSize
    } else { 'Dossier programme absent.' }
}

AddCommandResult 'PROCESSUS' {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue |`n        Where-Object { $_.CommandLine -match '(?i)F1TEQRadioAgent' } |`n        Select-Object ProcessId,Name,CommandLine | Format-List
}


AddCommandResult 'ETAT DU MOTEUR' {
    foreach ($name in @('workerstatus.json','worker.pid','config.json')) {
        $p = Join-Path $DataRoot $name
        "--- $name ---"
        if (Test-Path -LiteralPath $p) { Get-Content -LiteralPath $p -Raw } else { 'Absent' }
    }
}

AddCommandResult 'HAMLIB' {
    $rig = Get-ChildItem -LiteralPath (Join-Path $AppRoot 'Hamlib') -Filter 'rigctl.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $rig) { 'rigctl.exe absent.'; return }
    "Chemin : $($rig.FullName)"
    & $rig.FullName --version 2>&1
    $models = & $rig.FullName -l 2>&1
    "Lignes modeles : $(@($models | Where-Object { [string]$_ -match '^\s*\d+\s+' }).Count)"
}

AddCommandResult 'RESEAU GITHUB' {
    Test-NetConnection github.com -Port 443 -InformationLevel Detailed
}
AddCommandResult 'RESEAU SOURCEFORGE' {
    Test-NetConnection sourceforge.net -Port 443 -InformationLevel Detailed
}
AddCommandResult 'DNS' {
    Resolve-DnsName github.com -ErrorAction Continue
    Resolve-DnsName sourceforge.net -ErrorAction Continue
}
AddCommandResult 'CURL' {
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) { & $curl.Source --version } else { 'curl.exe absent.' }
}
AddCommandResult 'BITS' {
    Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue | Format-List Name,Source,Version
}
AddCommandResult 'SECURITE WINDOWS RECENTE' {
    try {
        Get-MpThreatDetection -ErrorAction Stop | Select-Object -First 10 InitialDetectionTime,ThreatName,ActionSuccess,Resources | Format-List
    } catch { "Informations Defender indisponibles : $($_.Exception.Message)" }
}
AddCommandResult 'PORTS COM' {
    [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object
}
AddCommandResult 'JOURNAL INSTALLATION' {
    $p = Join-Path $DataRoot 'installation.log'
    if (Test-Path -LiteralPath $p) { Get-Content -LiteralPath $p -Tail 200 } else { 'Journal absent.' }
}
AddCommandResult 'JOURNAL AGENT' {
    $p = Join-Path $DataRoot 'agent.log'
    if (Test-Path -LiteralPath $p) { Get-Content -LiteralPath $p -Tail 200 } else { 'Journal absent.' }
}
AddCommandResult 'CONTROLE APPLICATION WINDOWS' {
    try {
        Get-WinEvent -FilterHashtable @{ LogName='Microsoft-Windows-CodeIntegrity/Operational'; StartTime=(Get-Date).AddDays(-1) } -ErrorAction Stop |
            Where-Object { $_.Id -in 3033,3077,3089 } |
            Select-Object -First 20 TimeCreated,Id,Message | Format-List
    } catch { "Journal CodeIntegrity indisponible : $($_.Exception.Message)" }
    try {
        Get-WinEvent -FilterHashtable @{ LogName='Microsoft-Windows-AppLocker/EXE and DLL'; StartTime=(Get-Date).AddDays(-1) } -ErrorAction Stop |
            Where-Object { $_.Id -in 8004,8029,8036 } |
            Select-Object -First 20 TimeCreated,Id,Message | Format-List
    } catch { "Journal AppLocker indisponible : $($_.Exception.Message)" }
}

$lines | Set-Content -LiteralPath $Report -Encoding UTF8
AddLine ''
AddLine "Rapport cree : $Report"
Start-Process notepad.exe $Report
