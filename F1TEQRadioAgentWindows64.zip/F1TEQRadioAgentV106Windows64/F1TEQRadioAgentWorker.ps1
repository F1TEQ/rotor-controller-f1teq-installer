﻿#requires -version 5.1
<#
F1TEQ Radio Agent 1.0.6 - moteur de fond
Ce processus execute Hamlib et le reseau hors du thread de l interface.
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Net.Http

$script:AgentVersion = '1.0.6'
$script:HamlibVersion = '4.7.2'
$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:HamlibRoot = Join-Path $script:Root 'Hamlib'
$script:DataRoot = Join-Path $env:APPDATA 'F1TEQ\RadioAgent'
$script:ConfigFile = Join-Path $script:DataRoot 'config.json'
$script:StatusFile = Join-Path $script:DataRoot 'workerstatus.json'
$script:PidFile = Join-Path $script:DataRoot 'worker.pid'
$script:StopFile = Join-Path $script:DataRoot 'arretdemande.txt'
$script:LogFile = Join-Path $script:DataRoot 'agent.log'
$script:RawModelsFile = Join-Path $script:DataRoot 'modeleshamlibbrut.txt'
$script:RigCtl = $null
$script:Models = @()
$script:ModelsJson = '[]'
$script:ControllerStates = @{}
$script:CachedPorts = @()
$script:LastPortRefresh = [DateTime]::MinValue
$script:DiscoveredControllers = @()
$script:LastDiscovery = [DateTime]::MinValue
$script:DiscoveryPort = 4534
$script:AgentId = ('{0}-{1}' -f $env:COMPUTERNAME, $env:USERNAME)
$script:LastError = ''

New-Item -ItemType Directory -Force -Path $script:DataRoot | Out-Null

$createdNew = $false
$script:WorkerMutex = [System.Threading.Mutex]::new($true, 'Local\F1TEQRadioAgentWorker', [ref]$createdNew)
if (-not $createdNew) { exit 0 }

function Write-Log {
    param([string]$Message, [switch]$Error)
    $line = '[{0}] MOTEUR : {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    try { Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8 } catch {}
    if ($Error) { $script:LastError = $Message }
}

function Write-JsonAtomic {
    param([string]$Path, $Value)
    $tmp = $Path + '.tmp.' + [Guid]::NewGuid().ToString('N')
    try {
        $Value | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $tmp -Encoding UTF8
        Move-Item -LiteralPath $tmp -Destination $Path -Force
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Write-Status {
    param(
        [string]$State,
        [string]$Message,
        [int]$ConnectedCount = 0,
        [int]$ControllerCount = 0
    )
    $value = [ordered]@{
        timestamp = (Get-Date).ToString('o')
        state = $State
        message = $Message
        worker_pid = $PID
        connected_count = $ConnectedCount
        controller_count = $ControllerCount
        models_count = @($script:Models).Count
        hamlib_version = $script:HamlibVersion
        last_error = $script:LastError
    }
    try { Write-JsonAtomic -Path $script:StatusFile -Value $value } catch {}
}

function Stop-Requested {
    return Test-Path -LiteralPath $script:StopFile
}

function Sleep-Interruptible {
    param([int]$Milliseconds)
    $remaining = $Milliseconds
    while ($remaining -gt 0) {
        if (Stop-Requested) { return $false }
        $chunk = [Math]::Min(100, $remaining)
        Start-Sleep -Milliseconds $chunk
        $remaining -= $chunk
    }
    return $true
}

function Normalize-ControllerUrl {
    param([string]$Value)
    $value = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) { return $null }
    if ($value -notmatch '^https?://') { $value = 'http://' + $value }
    return $value.TrimEnd('/')
}

function Load-ControllerUrls {
    $items = New-Object System.Collections.Generic.List[string]
    try {
        if (Test-Path -LiteralPath $script:ConfigFile) {
            $config = Get-Content -LiteralPath $script:ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($entry in @($config.controllers)) {
                $url = Normalize-ControllerUrl ([string]$entry)
                if ($url -and -not $items.Contains($url)) { $items.Add($url) }
            }
        }
    } catch {
        Write-Log "Lecture temporairement impossible de la configuration : $($_.Exception.Message)"
    }
    foreach ($entry in @($script:DiscoveredControllers)) {
        $url = Normalize-ControllerUrl ([string]$entry)
        if ($url -and -not $items.Contains($url)) { $items.Add($url) }
    }
    if ($items.Count -eq 0) { $items.Add('http://rotor.local') }
    return @($items)
}

function Find-RigCtl {
    $candidate = Get-ChildItem -LiteralPath $script:HamlibRoot -Filter 'rigctl.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($candidate) { return $candidate.FullName }
    return $null
}

function Invoke-HamlibModelList {
    $rigDirectory = Split-Path -Parent $script:RigCtl
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $script:RigCtl
    $info.Arguments = '-l'
    $info.WorkingDirectory = $rigDirectory
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.EnvironmentVariables['PATH'] = $rigDirectory + ';' + $info.EnvironmentVariables['PATH']
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    if (-not $process.Start()) { throw 'Impossible de demarrer rigctl.exe.' }
    $outTask = $process.StandardOutput.ReadToEndAsync()
    $errTask = $process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit(20000)) {
        try { $process.Kill() } catch {}
        throw 'Hamlib ne repond pas lors de la lecture des modeles.'
    }
    $text = ($outTask.GetAwaiter().GetResult() + [Environment]::NewLine + $errTask.GetAwaiter().GetResult()).Trim()
    $exitCode = $process.ExitCode
    $process.Dispose()
    try { Set-Content -LiteralPath $script:RawModelsFile -Value $text -Encoding UTF8 } catch {}
    $validCount = @($text -split '\r?\n' | Where-Object { ([string]$_).Trim() -match '^\d+\s+' }).Count
    if ($validCount -lt 50) { throw "Liste Hamlib incomplete : $validCount modeles, code $exitCode." }
    if ($exitCode -ne 0) { Write-Log "rigctl -l a retourne le code $exitCode mais $validCount modeles valides ont ete conserves." }
    return @($text -split '\r?\n')
}

function Refresh-Models {
    $models = New-Object System.Collections.Generic.List[object]
    foreach ($raw in @(Invoke-HamlibModelList)) {
        $line = ([string]$raw).Trim()
        if ($line -notmatch '^\d+\s+') { continue }
        $parts = @($line -split '\s+')
        if ($parts.Count -lt 5) { continue }
        $id = 0
        if (-not [int]::TryParse($parts[0], [ref]$id) -or $id -le 0) { continue }
        $manufacturer = $parts[1].Trim()
        $status = $parts[$parts.Count - 1].Trim()
        $version = $parts[$parts.Count - 2].Trim()
        $modelName = (@($parts[2..($parts.Count - 3)]) -join ' ').Trim()
        if ([string]::IsNullOrWhiteSpace($manufacturer) -or [string]::IsNullOrWhiteSpace($modelName)) { continue }
        $models.Add([pscustomobject][ordered]@{
            id = $id
            mfg = $manufacturer
            model = $modelName
            version = $version
            status = $status
        })
    }
    $script:Models = @($models | Sort-Object mfg, model, id -Unique)
    if ($script:Models.Count -lt 50) { throw "Seulement $($script:Models.Count) modeles Hamlib ont ete analyses." }
    $script:ModelsJson = $script:Models | ConvertTo-Json -Compress -Depth 4
    Write-Log "$($script:Models.Count) modeles Hamlib charges."
}

function Get-ComPorts {
    if (((Get-Date) - $script:LastPortRefresh).TotalSeconds -lt 3) { return $script:CachedPorts }
    try { $script:CachedPorts = @([System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object) } catch { $script:CachedPorts = @() }
    $script:LastPortRefresh = Get-Date
    return $script:CachedPorts
}

function New-HttpClient {
    $handler = New-Object System.Net.Http.HttpClientHandler
    $client = New-Object System.Net.Http.HttpClient($handler)
    $client.Timeout = [TimeSpan]::FromSeconds(3)
    return $client
}

function Post-Json {
    param([string]$Url, [string]$Json)
    $client = New-HttpClient
    try {
        $content = New-Object System.Net.Http.StringContent($Json, [Text.Encoding]::UTF8, 'application/json')
        $response = $client.PostAsync($Url, $content).GetAwaiter().GetResult()
        $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        if (-not $response.IsSuccessStatusCode) { throw "HTTP $([int]$response.StatusCode) : $body" }
        return $body
    } finally { $client.Dispose() }
}

function Discover-Controllers {
    $found = New-Object System.Collections.Generic.List[string]
    try {
        $udp = New-Object -TypeName System.Net.Sockets.UdpClient -ArgumentList 0
        try {
            $udp.EnableBroadcast = $true
            $udp.Client.ReceiveTimeout = 150
            $message = [Text.Encoding]::ASCII.GetBytes('F1TEQ_ROTOR_DISCOVER_V1')
            $destination = New-Object -TypeName System.Net.IPEndPoint -ArgumentList @([System.Net.IPAddress]::Broadcast, $script:DiscoveryPort)
            [void]$udp.Send($message, $message.Length, $destination)
            $deadline = (Get-Date).AddMilliseconds(700)
            while ((Get-Date) -lt $deadline -and -not (Stop-Requested)) {
                try {
                    $remote = New-Object -TypeName System.Net.IPEndPoint -ArgumentList @([System.Net.IPAddress]::Any, 0)
                    $bytes = $udp.Receive([ref]$remote)
                    $info = ([Text.Encoding]::UTF8.GetString($bytes)) | ConvertFrom-Json
                    if ([string]$info.service -ne 'F1TEQ_ROTOR_CONTROLLER') { continue }
                    $url = Normalize-ControllerUrl ([string]$info.url)
                    if (-not $url -and $remote.Address) { $url = 'http://' + $remote.Address.IPAddressToString }
                    if ($url -and -not $found.Contains($url)) { $found.Add($url) }
                } catch [System.Net.Sockets.SocketException] {
                } catch {
                    Write-Log "Reponse de decouverte ignoree : $($_.Exception.Message)"
                }
            }
        } finally { $udp.Close(); $udp.Dispose() }
    } catch { Write-Log "Decouverte automatique indisponible : $($_.Exception.Message)" }
    $script:DiscoveredControllers = @($found)
    $script:LastDiscovery = Get-Date
    if ($found.Count -gt 0) { Write-Log "$($found.Count) controleur(s) detecte(s) automatiquement." }
}

function Get-StateForController {
    param([string]$Controller)
    if (-not $script:ControllerStates.ContainsKey($Controller)) {
        $script:ControllerStates[$Controller] = [pscustomobject][ordered]@{
            AckId = 0
            AckOk = $false
            AckMessage = ''
            LastProcessedId = 0
            LastModelsUpload = [DateTime]::MinValue
            ModelsUploadedFor = ''
            ControllerSession = [uint64]0
        }
    }
    return $script:ControllerStates[$Controller]
}

function Quote-WindowsArgument {
    param([string]$Value)
    if ($Value -notmatch '[\s"]') { return $Value }
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function Invoke-RigCtlCommand {
    param($Command)
    $modelId = [int]$Command.model_id
    $device = [string]$Command.port
    $baud = [int]$Command.baud
    $type = [string]$Command.type
    $mode = if ([string]::IsNullOrWhiteSpace([string]$Command.mode)) { 'CW' } else { [string]$Command.mode }
    $freq = [string]$Command.frequency_hz
    if ($modelId -le 0) { return @{ Ok=$false; Message='Modele Hamlib invalide.' } }
    if ([string]::IsNullOrWhiteSpace($device)) { return @{ Ok=$false; Message='Port CAT manquant.' } }
    if ($baud -le 0) { return @{ Ok=$false; Message='Choisissez le debit CAT exact du poste dans Ma station.' } }

    $args = @('-m',[string]$modelId,'-r',$device,'-s',[string]$baud,'-')
    $argString = ($args | ForEach-Object { Quote-WindowsArgument ([string]$_) }) -join ' '
    $rigDirectory = Split-Path -Parent $script:RigCtl
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $script:RigCtl
    $info.Arguments = $argString
    $info.WorkingDirectory = $rigDirectory
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.EnvironmentVariables['PATH'] = $rigDirectory + ';' + $info.EnvironmentVariables['PATH']
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    try {
        if (-not $process.Start()) { throw 'Impossible de lancer rigctl.exe.' }
        $outTask = $process.StandardOutput.ReadToEndAsync()
        $errTask = $process.StandardError.ReadToEndAsync()
        if ($type -eq 'tune') {
            if ($freq -notmatch '^\d{5,14}$') { throw 'Frequence CAT invalide.' }
            $process.StandardInput.WriteLine("F $freq")
            $process.StandardInput.WriteLine("M $mode 0")
            $process.StandardInput.WriteLine('f')
            $process.StandardInput.WriteLine('m')
        } else {
            $process.StandardInput.WriteLine('f')
            $process.StandardInput.WriteLine('m')
        }
        $process.StandardInput.Close()
        if (-not $process.WaitForExit(12000)) {
            try { $process.Kill() } catch {}
            return @{ Ok=$false; Message='Le poste ne repond pas dans le delai imparti.' }
        }
        $combined = (($outTask.GetAwaiter().GetResult() + ' ' + $errTask.GetAwaiter().GetResult()) -replace '[\r\n]+',' ').Trim()
        if ($combined.Length -gt 180) { $combined = $combined.Substring(0,180) }
        if ($process.ExitCode -ne 0 -or $combined -match 'RPRT\s+-\d+') {
            if ([string]::IsNullOrWhiteSpace($combined)) { $combined = "rigctl a retourne le code $($process.ExitCode)." }
            return @{ Ok=$false; Message=$combined }
        }
        if ($type -eq 'tune') { return @{ Ok=$true; Message=("Poste regle sur $freq Hz en $mode. $combined").Trim() } }
        return @{ Ok=$true; Message=("Liaison CAT operationnelle a $baud bauds. $combined").Trim() }
    } catch { return @{ Ok=$false; Message=$_.Exception.Message } }
    finally { $process.Dispose() }
}

function Upload-Models {
    param([string]$Controller, $State)
    if ([string]::IsNullOrWhiteSpace($script:ModelsJson) -or $script:ModelsJson -eq '[]') { return }
    if (((Get-Date) - $State.LastModelsUpload).TotalSeconds -lt 20) { return }
    $uri = "$Controller/cat/agent/modeles?hamlib=$([Uri]::EscapeDataString($script:HamlibVersion))"
    Post-Json -Url $uri -Json $script:ModelsJson | Out-Null
    $State.LastModelsUpload = Get-Date
    $State.ModelsUploadedFor = $script:HamlibVersion
    Write-Log "Liste des modeles envoyee a $Controller."
}

function Poll-Controller {
    param([string]$Controller)
    $state = Get-StateForController $Controller
    $payload = [ordered]@{
        agent_id = $script:AgentId
        agent_version = $script:AgentVersion
        hamlib_version = $script:HamlibVersion
        ports = @(Get-ComPorts)
        ack_id = [uint32]$state.AckId
        ack_ok = [bool]$state.AckOk
        ack_message = [string]$state.AckMessage
        controller_session = [uint64]$state.ControllerSession
    }
    $body = Post-Json -Url "$Controller/cat/agent/poll" -Json ($payload | ConvertTo-Json -Compress -Depth 5)
    $response = $body | ConvertFrom-Json
    $newSession = [uint64]$response.session_id
    if ($newSession -ne 0 -and [uint64]$state.ControllerSession -ne $newSession) {
        $state.ControllerSession = $newSession
        $state.AckId = 0; $state.AckOk = $false; $state.AckMessage = ''; $state.LastProcessedId = 0
        Write-Log "Nouvelle session detectee pour $Controller."
    }
    if ($state.AckId -ne 0) { $state.AckId = 0; $state.AckOk = $false; $state.AckMessage = '' }
    if ($response.models_needed -eq $true -or $state.ModelsUploadedFor -ne $script:HamlibVersion) {
        Upload-Models -Controller $Controller -State $state
    }
    if ($response.command -and [uint32]$response.command.id -ne 0) {
        $id = [uint32]$response.command.id
        if ($id -ne [uint32]$state.LastProcessedId) {
            $state.LastProcessedId = $id
            Write-Log "Commande $id recue de $Controller."
            $result = Invoke-RigCtlCommand -Command $response.command
            $message = [string]$result.Message
            if ($message.Length -gt 210) { $message = $message.Substring(0,210) }
            $state.AckId = $id
            $state.AckOk = [bool]$result.Ok
            $state.AckMessage = $message
            Write-Log ("Commande {0} : {1}" -f $id,$message) -Error:(-not [bool]$result.Ok)
        }
    }
    return $true
}

try {
    Set-Content -LiteralPath $script:PidFile -Value ([string]$PID) -Encoding ASCII -Force
    Write-Status -State 'starting' -Message 'Chargement de Hamlib et de la liste des postes...'
    Write-Log "Moteur F1TEQ Radio Agent $($script:AgentVersion) demarre."
    $script:RigCtl = Find-RigCtl
    if (-not $script:RigCtl) { throw 'Hamlib est absent. Relancez INSTALLER.cmd.' }
    Refresh-Models
    Discover-Controllers

    while (-not (Stop-Requested)) {
        if (((Get-Date) - $script:LastDiscovery).TotalSeconds -ge 60) { Discover-Controllers }
        $urls = @(Load-ControllerUrls)
        $connected = 0
        foreach ($url in $urls) {
            if (Stop-Requested) { break }
            try {
                if (Poll-Controller $url) { $connected++ }
            } catch {
                Write-Log "$url : $($_.Exception.Message)" -Error
            }
        }
        if ($connected -gt 0) {
            Write-Status -State 'running' -Message "$connected controleur(s) connecte(s) — $($script:Models.Count) modeles Hamlib" -ConnectedCount $connected -ControllerCount $urls.Count
        } else {
            Write-Status -State 'running' -Message "Aucun controleur joignable — $($script:Models.Count) modeles Hamlib charges" -ConnectedCount 0 -ControllerCount $urls.Count
        }
        if (-not (Sleep-Interruptible 1500)) { break }
    }
    Write-Status -State 'stopping' -Message 'Arret du moteur...'
    Write-Log 'Moteur arrete proprement.'
    Write-Status -State 'stopped' -Message 'Agent arrete.'
    exit 0
} catch {
    $message = $_.Exception.Message
    Write-Log $message -Error
    Write-Status -State 'error' -Message $message
    exit 1
} finally {
    Remove-Item -LiteralPath $script:PidFile -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $script:StopFile -Force -ErrorAction SilentlyContinue
    if ($script:WorkerMutex) {
        try { $script:WorkerMutex.ReleaseMutex() } catch {}
        $script:WorkerMutex.Dispose()
    }
}
