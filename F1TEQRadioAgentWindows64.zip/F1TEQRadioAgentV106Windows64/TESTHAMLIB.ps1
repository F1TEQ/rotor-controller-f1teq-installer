﻿#requires -version 5.1
$ErrorActionPreference = 'Stop'
$AppRoot = Join-Path $env:LOCALAPPDATA 'F1TEQ\RadioAgentApp'
$RigCtl = Get-ChildItem -LiteralPath (Join-Path $AppRoot 'Hamlib') -Filter 'rigctl.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $RigCtl) { throw 'rigctl.exe est introuvable. Relancez INSTALLER.cmd.' }
$RigDirectory = Split-Path -Parent $RigCtl.FullName
$Info = New-Object System.Diagnostics.ProcessStartInfo
$Info.FileName = $RigCtl.FullName
$Info.Arguments = '-l'
$Info.WorkingDirectory = $RigDirectory
$Info.UseShellExecute = $false
$Info.CreateNoWindow = $true
$Info.RedirectStandardOutput = $true
$Info.RedirectStandardError = $true
$Info.EnvironmentVariables['PATH'] = $RigDirectory + ';' + $Info.EnvironmentVariables['PATH']
$P = New-Object System.Diagnostics.Process
$P.StartInfo = $Info
[void]$P.Start()
$OutTask = $P.StandardOutput.ReadToEndAsync()
$ErrTask = $P.StandardError.ReadToEndAsync()
if (-not $P.WaitForExit(20000)) { try { $P.Kill() } catch {}; throw 'Delai Hamlib depasse.' }
$Text = ($OutTask.GetAwaiter().GetResult() + [Environment]::NewLine + $ErrTask.GetAwaiter().GetResult()).Trim()
$Code = $P.ExitCode
$P.Dispose()
$Lines = @($Text -split '\r?\n')
$Valid = @($Lines | Where-Object { $_.Trim() -match '^\d+\s+' })
Write-Host ''
Write-Host ('rigctl : ' + $RigCtl.FullName)
Write-Host ('Code   : ' + $Code)
Write-Host ('Lignes de modeles : ' + $Valid.Count)
Write-Host ''
$Valid | Select-Object -First 20 | ForEach-Object { Write-Host $_ }
Write-Host ''
Write-Host 'Le test doit afficher plusieurs centaines de lignes et notamment Icom, Yaesu et Kenwood.'

if ($Code -ne 0 -and $Valid.Count -ge 50) { Write-Host 'Le code non nul est ignore car la liste des modeles est complete.' -ForegroundColor Yellow }
