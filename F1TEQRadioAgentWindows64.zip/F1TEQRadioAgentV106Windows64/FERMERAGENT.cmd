@echo off
setlocal
chcp 65001 >nul
echo.
echo Fermeture forcee de F1TEQ Radio Agent...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0FERMERAGENT.ps1"
echo.
pause
endlocal
