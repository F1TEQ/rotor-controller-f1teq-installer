﻿#requires -version 5.1
$ErrorActionPreference = 'SilentlyContinue'
$DataRoot = Join-Path $env:APPDATA 'F1TEQ\RadioAgent'
$StopFile = Join-Path $DataRoot 'arretdemande.txt'
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
Set-Content -LiteralPath $StopFile -Value (Get-Date).ToString('o') -Encoding ASCII -Force
Start-Sleep -Milliseconds 300
$trouves = @(
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" |
        Where-Object { $_.CommandLine -match '(?i)(F1TEQRadioAgent|F1TEQRadioAgentWorker)\.ps1' }
)
if ($trouves.Count -eq 0) {
    Write-Host 'Aucune instance F1TEQ Radio Agent n est ouverte.' -ForegroundColor Yellow
    exit 0
}
foreach ($processus in $trouves) {
    Write-Host ("Fermeture du processus {0}." -f $processus.ProcessId)
    Stop-Process -Id $processus.ProcessId -Force -ErrorAction SilentlyContinue
}
Remove-Item -LiteralPath (Join-Path $DataRoot 'worker.pid') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $StopFile -Force -ErrorAction SilentlyContinue
Write-Host 'F1TEQ Radio Agent et son moteur sont fermes.' -ForegroundColor Green
